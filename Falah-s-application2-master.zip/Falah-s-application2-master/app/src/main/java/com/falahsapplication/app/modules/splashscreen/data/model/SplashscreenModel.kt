package com.falahsapplication.app.modules.splashscreen.`data`.model

class SplashscreenModel()
