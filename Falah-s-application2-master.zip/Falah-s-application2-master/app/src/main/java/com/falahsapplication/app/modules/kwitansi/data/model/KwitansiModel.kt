package com.falahsapplication.app.modules.kwitansi.`data`.model

class KwitansiModel()
