package com.falahsapplication.app.modules.minuman.`data`.model

class MinumanModel()
